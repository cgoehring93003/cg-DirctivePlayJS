

var app = angular.module('app', ['ui.router']);


app.config(function($stateProvider, $urlRouterProvider){

	$urlRouterProvider.otherwise('/');

	$stateProvider
		.state('home', {
			url: '/',
			data: {crumbName: 'Home'},
			template: '	Click <a ui-sref="list">here</a> to show list<ui-view></ui-view>'
		})
		.state('list', {
			parent: 'home',
			url: 'list',
			data: {crumbName: 'List'},
			templateUrl: 'templates/list.html',
			controller: 'listCtrl',
			resolve: {
				users: function(userSvc){
					return userSvc.all()
				}
			}
		})
		.state('details', {
			parent: 'list',
			url: 'details/:id',
			data: {crumbName: 'Details'},
			templateUrl: 'templates/list.details.html',
			controller: 'detailsCtrl',
			resolve: {
				user: function(userSvc, $stateParams){
					return userSvc.one($stateParams.id);
				}
			}
		})
});

app.run(function($rootScope){
	$rootScope.$on('$stateChangeError', function(event, toState, toParams, fromState, fromParams, error){
		console.log(error)
		console.log(toState)
		console.log(fromState)
	});
})

app.controller('bodyCtrl', function($scope, $state){
	$scope.$state = $state;
	$scope.crumbs = [{name: 'home', url: '/'}];

	$scope.$on('$stateChangeSuccess', function(event, toState){
		var crumbs = [];
		var state = $scope.$state.get(toState.name);
		do{
			crumbs.unshift({name: state.data.crumbName, url: $scope.$state.href(state.name)});
			state = $scope.$state.get(state.parent);
		}while(state)
		$scope.crumbs = crumbs;
	})
})

app.controller('listCtrl', function($scope, users){
	$scope.users = users;
})

app.controller('detailsCtrl', function($scope, user){
	$scope.user = user;
})


app.factory('userSvc', function($http){
	var users = function(){
		return $http.get('data/users.json')
			.then(function(resp){
				return resp.data;
			})
	};

	var $ = {};

	$.all = function(){
		return users();
	};

	$.one = function(id){
		return users().then(function(arr){
			return _.find(arr, function(v){
				return id == v.id;
			})
		})
	}
	return $;
})


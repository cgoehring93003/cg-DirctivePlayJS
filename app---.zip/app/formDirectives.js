

myApp.directive("myTable", function() {
    return {
		replace: true,
        templateUrl : 'templates/myTableTemplate.html'

    };
});		


	


var myApp = angular.module('myApp', ['ui.router', '720kb.tooltips'])

.config(function($stateProvider, $urlRouterProvider, $locationProvider) {
 

	$locationProvider.html5Mode(false);
 
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        .state('home', {
            url: '/home',
            templateUrl: 'templates/home.html'
        })
		.state('edit', {
            url: '/edit/:id',
			controller: 'formController as fmc',
			templateUrl: 'templates/editAddressForm.html',
         resolve: {
            record: function ($stateParams, addressService ) {
               return addressService.getAddress($stateParams.id);
            }
		 }
		})		  
        .state('about', {
            url: '/about',
            templateUrl: 'templates/about.html' 
        });
        
})


.run(function($rootScope) {
  $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {
    console.log('$stateChangeError - fired when an error occurs during transition.');
    //console.log(arguments);

    console.log('arguments: ' + error);
    console.log('arguments: ' + toParams);
    console.log('arguments: ' + fromParams);

  });
  
  $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
    console.log('$stateChangeSuccess to ' + toState.name + ' - fired once the state transition is complete.');

    console.log('arguments: toParams: ' + JSON.stringify(toParams));

  });

});


	
